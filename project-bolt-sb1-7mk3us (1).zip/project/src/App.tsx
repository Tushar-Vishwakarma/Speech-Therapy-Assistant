import React from 'react';
import { useStore } from './store/useStore';
import { Dashboard } from './components/Dashboard';
import { ExerciseCard } from './components/ExerciseCard';
import { ExerciseView } from './components/ExerciseView';
import { Brain, Mic, BookOpen, PenTool } from 'lucide-react';

function App() {
  const { exercises, currentExercise, setCurrentExercise, completeExercise } = useStore();

  const sections = [
    {
      type: 'pronunciation',
      title: 'Pronunciation Practice',
      description: 'Master speech sounds and clarity',
      icon: <Mic className="w-6 h-6 text-blue-500" />,
      color: 'blue',
    },
    {
      type: 'vocabulary',
      title: 'Vocabulary Building',
      description: 'Learn new words and their meanings',
      icon: <BookOpen className="w-6 h-6 text-green-500" />,
      color: 'green',
    },
    {
      type: 'sentence',
      title: 'Sentence Formation',
      description: 'Create complete and meaningful sentences',
      icon: <PenTool className="w-6 h-6 text-purple-500" />,
      color: 'purple',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2">
            <Brain className="w-8 h-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">
              Speech Therapy Assistant
            </h1>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {currentExercise ? (
              <ExerciseView
                exercise={currentExercise}
                onComplete={(score) => {
                  completeExercise(currentExercise.id, score);
                  setCurrentExercise(currentExercise);
                }}
                onBack={() => setCurrentExercise(null)}
              />
            ) : (
              <div className="space-y-8">
                {sections.map((section) => (
                  <div
                    key={section.type}
                    className={`bg-${section.color}-50 p-6 rounded-lg`}
                  >
                    <div className="flex items-center gap-3 mb-4">
                      {section.icon}
                      <div>
                        <h2 className="text-xl font-bold">{section.title}</h2>
                        <p className="text-gray-600">{section.description}</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {exercises
                        .filter((ex) => ex.type === section.type)
                        .map((exercise) => (
                          <ExerciseCard
                            key={exercise.id}
                            exercise={exercise}
                            onSelect={setCurrentExercise}
                          />
                        ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="lg:col-span-1">
            <Dashboard />
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;