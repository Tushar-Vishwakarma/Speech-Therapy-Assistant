export interface Exercise {
  id: string;
  title: string;
  description: string;
  type: 'pronunciation' | 'vocabulary' | 'sentence';
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  completed: boolean;
  content: ExerciseContent;
}

export interface ExerciseContent {
  instructions: string;
  examples: string[];
  targetWords?: string[];
  imageUrl?: string;
  expectedResponse?: string;
}

export interface ProgressData {
  date: string;
  score: number;
  category: string;
}

export interface UserProfile {
  name: string;
  age: number;
  focusAreas: string[];
  progressData: ProgressData[];
}