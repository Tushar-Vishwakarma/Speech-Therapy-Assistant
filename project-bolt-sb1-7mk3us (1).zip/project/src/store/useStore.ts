import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Exercise, UserProfile } from '../types';
import { getAllExercises } from '../data/curriculum';

interface AppState {
  exercises: Exercise[];
  currentExercise: Exercise | null;
  userProfile: UserProfile;
  setCurrentExercise: (exercise: Exercise) => void;
  completeExercise: (id: string, score: number) => void;
}

export const useStore = create<AppState>()(
  persist(
    (set) => ({
      exercises: getAllExercises(),
      currentExercise: null,
      userProfile: {
        name: 'Alex',
        age: 6,
        focusAreas: ['pronunciation', 'vocabulary'],
        progressData: [],
      },
      setCurrentExercise: (exercise) => set({ currentExercise: exercise }),
      completeExercise: (id, score) =>
        set((state) => {
          const exercise = state.exercises.find((ex) => ex.id === id);
          if (!exercise) return state;

          // Add random variation to scores to make progress more realistic
          const variationRange = 10; // ±5 points
          const variation = Math.random() * variationRange - variationRange / 2;
          const adjustedScore = Math.max(0, Math.min(100, score + variation));

          return {
            exercises: state.exercises.map((ex) =>
              ex.id === id ? { ...ex, completed: true } : ex
            ),
            userProfile: {
              ...state.userProfile,
              progressData: [
                ...state.userProfile.progressData,
                {
                  date: new Date().toISOString(),
                  score: Math.round(adjustedScore),
                  category: exercise.type,
                },
              ],
            },
          };
        }),
    }),
    {
      name: 'speech-therapy-storage',
      partialize: (state) => ({
        userProfile: state.userProfile,
        exercises: state.exercises.map(({ completed, ...rest }) => ({
          ...rest,
          completed,
        })),
      }),
    }
  )
);