import { pronunciationExercises } from './exercises/pronunciation';
import { vocabularyExercises } from './exercises/vocabulary';
import { sentenceExercises } from './exercises/sentences';

export const curriculumPlan = {
  pronunciation: {
    title: 'Pronunciation Training',
    description: '30 days of structured pronunciation practice',
    weeks: [
      {
        week: 1,
        theme: 'Basic Sounds',
        goals: ['Master vowel sounds', 'Practice basic consonants', 'Blend simple sounds'],
      },
      {
        week: 2,
        theme: 'Sound Combinations',
        goals: ['Practice consonant blends', 'Work on digraphs', 'Improve sound clarity'],
      },
      // Weeks 3-4...
    ],
  },
  vocabulary: {
    title: 'Vocabulary Building',
    description: '30 days of vocabulary expansion',
    weeks: [
      {
        week: 1,
        theme: 'Basic Categories',
        goals: ['Learn family words', 'Master animal names', 'Identify common objects'],
      },
      {
        week: 2,
        theme: 'Actions and Feelings',
        goals: ['Learn action words', 'Express emotions', 'Describe activities'],
      },
      // Weeks 3-4...
    ],
  },
  sentences: {
    title: 'Sentence Formation',
    description: '30 days of sentence building practice',
    weeks: [
      {
        week: 1,
        theme: 'Basic Communication',
        goals: ['Make simple requests', 'Express basic needs', 'Share feelings'],
      },
      {
        week: 2,
        theme: 'Daily Activities',
        goals: ['Describe routines', 'Talk about preferences', 'Ask questions'],
      },
      // Weeks 3-4...
    ],
  },
};

export const getAllExercises = () => [
  ...pronunciationExercises,
  ...vocabularyExercises,
  ...sentenceExercises,
];