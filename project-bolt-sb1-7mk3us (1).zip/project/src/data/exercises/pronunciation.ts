import { Exercise } from '../../types';

export const pronunciationExercises: Exercise[] = [
  // Week 1: Basic Sounds
  {
    id: 'p1',
    title: 'Basic Vowel Sounds',
    description: 'Practice basic vowel sounds (a, e, i, o, u)',
    type: 'pronunciation',
    difficulty: 'beginner',
    completed: false,
    content: {
      instructions: 'Listen and repeat each vowel sound clearly',
      examples: ['A as in "apple"', 'E as in "egg"', 'I as in "igloo"'],
      targetWords: ['apple', 'egg', 'igloo', 'orange', 'umbrella'],
      imageUrl: 'https://images.unsplash.com/photo-1544033527-b192daee1f5b?auto=format&fit=crop&w=300',
    },
    day: 1,
  },
  {
    id: 'p2',
    title: 'Simple Consonants',
    description: 'Master basic consonant sounds (m, n, p, b)',
    type: 'pronunciation',
    difficulty: 'beginner',
    completed: false,
    content: {
      instructions: 'Practice each consonant sound with a simple word',
      examples: ['M as in "mom"', 'N as in "no"', 'P as in "pop"'],
      targetWords: ['mom', 'no', 'pop', 'baby'],
      imageUrl: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&w=300',
    },
    day: 2,
  },
  // Additional exercises for days 3-30...
];