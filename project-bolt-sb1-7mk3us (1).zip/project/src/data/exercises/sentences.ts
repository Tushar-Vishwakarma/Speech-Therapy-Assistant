import { Exercise } from '../../types';

export const sentenceExercises: Exercise[] = [
  // Week 1: Basic Sentences
  {
    id: 's1',
    title: 'Simple Requests',
    description: 'Practice making basic requests',
    type: 'sentence',
    difficulty: 'beginner',
    completed: false,
    content: {
      instructions: 'Practice saying these simple requests',
      examples: ['I want water', 'Help me please', 'Thank you'],
      expectedResponse: 'I want [item]',
      imageUrl: 'https://images.unsplash.com/photo-1576267423048-15c0040fec78?auto=format&fit=crop&w=300',
    },
    day: 1,
  },
  {
    id: 's2',
    title: 'Daily Activities',
    description: 'Describe your daily activities',
    type: 'sentence',
    difficulty: 'beginner',
    completed: false,
    content: {
      instructions: 'Create sentences about what you do every day',
      examples: ['I eat breakfast', 'I play games', 'I go to bed'],
      expectedResponse: 'I [action] [object]',
      imageUrl: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&w=300',
    },
    day: 2,
  },
  // Additional exercises for days 3-30...
];