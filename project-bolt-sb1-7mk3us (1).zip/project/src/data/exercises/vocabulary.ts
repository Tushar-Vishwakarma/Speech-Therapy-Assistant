import { Exercise } from '../../types';

export const vocabularyExercises: Exercise[] = [
  // Week 1: Basic Categories
  {
    id: 'v1',
    title: 'Family Members',
    description: 'Learn words for family relationships',
    type: 'vocabulary',
    difficulty: 'beginner',
    completed: false,
    content: {
      instructions: 'Name each family member shown in the pictures',
      examples: ['Mom', 'Dad', 'Sister', 'Brother'],
      targetWords: ['mom', 'dad', 'sister', 'brother', 'baby'],
      imageUrl: 'https://images.unsplash.com/photo-1511895426328-dc8714191300?auto=format&fit=crop&w=300',
    },
    day: 1,
  },
  {
    id: 'v2',
    title: 'Common Animals',
    description: 'Learn names of common animals',
    type: 'vocabulary',
    difficulty: 'beginner',
    completed: false,
    content: {
      instructions: 'Name each animal and make its sound',
      examples: ['Dog (woof)', 'Cat (meow)', 'Cow (moo)'],
      targetWords: ['dog', 'cat', 'cow', 'bird', 'fish'],
      imageUrl: 'https://images.unsplash.com/photo-1583511655826-05700d52f4d9?auto=format&fit=crop&w=300',
    },
    day: 2,
  },
  // Additional exercises for days 3-30...
];