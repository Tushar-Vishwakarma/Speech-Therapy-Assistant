import React, { useMemo } from 'react';
import { Line } from 'react-chartjs-2';
import { useStore } from '../store/useStore';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

export const Dashboard: React.FC = () => {
  const { userProfile } = useStore();

  const stats = useMemo(() => {
    const categoryData = userProfile.progressData.reduce((acc, data) => {
      if (!acc[data.category]) {
        acc[data.category] = {
          scores: [],
          dates: [],
          trend: [],
          improvement: 0,
          averageScore: 0,
          bestScore: 0,
          completed: 0,
        };
      }
      
      acc[data.category].scores.push(data.score);
      acc[data.category].dates.push(new Date(data.date));
      acc[data.category].completed++;
      
      // Calculate moving average for trend
      const last5Scores = acc[data.category].scores.slice(-5);
      const movingAvg = last5Scores.reduce((a, b) => a + b, 0) / last5Scores.length;
      acc[data.category].trend.push(movingAvg);
      
      // Update statistics
      acc[data.category].averageScore = 
        acc[data.category].scores.reduce((a, b) => a + b, 0) / 
        acc[data.category].scores.length;
      acc[data.category].bestScore = Math.max(...acc[data.category].scores);
      
      // Calculate improvement (comparing last 3 vs first 3 attempts)
      if (acc[data.category].scores.length >= 6) {
        const first3Avg = acc[data.category].scores.slice(0, 3)
          .reduce((a, b) => a + b, 0) / 3;
        const last3Avg = acc[data.category].scores.slice(-3)
          .reduce((a, b) => a + b, 0) / 3;
        acc[data.category].improvement = ((last3Avg - first3Avg) / first3Avg) * 100;
      }
      
      return acc;
    }, {} as Record<string, {
      scores: number[];
      dates: Date[];
      trend: number[];
      improvement: number;
      averageScore: number;
      bestScore: number;
      completed: number;
    }>);

    return categoryData;
  }, [userProfile.progressData]);

  const chartData = {
    labels: userProfile.progressData.map(data => 
      new Date(data.date).toLocaleDateString()
    ),
    datasets: Object.entries(stats).map(([category, data]) => ({
      label: category.charAt(0).toUpperCase() + category.slice(1),
      data: data.scores,
      borderColor: 
        category === 'pronunciation' ? 'rgb(59, 130, 246)' : 
        category === 'vocabulary' ? 'rgb(16, 185, 129)' : 
        'rgb(139, 92, 246)',
      backgroundColor: 
        category === 'pronunciation' ? 'rgba(59, 130, 246, 0.1)' : 
        category === 'vocabulary' ? 'rgba(16, 185, 129, 0.1)' : 
        'rgba(139, 92, 246, 0.1)',
      tension: 0.3,
      fill: true,
    })),
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      tooltip: {
        mode: 'index' as const,
        intersect: false,
        callbacks: {
          label: (context: any) => {
            const label = context.dataset.label || '';
            const value = context.parsed.y;
            return `${label}: ${value.toFixed(1)}%`;
          },
        },
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 100,
        title: {
          display: true,
          text: 'Score (%)',
        },
      },
      x: {
        title: {
          display: true,
          text: 'Practice Date',
        },
        ticks: {
          maxTicksLimit: 8,
        },
      },
    },
    interaction: {
      intersect: false,
      mode: 'index',
    },
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-lg space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Progress Dashboard</h2>
        <div className="text-sm text-gray-500">
          Total Sessions: {userProfile.progressData.length}
        </div>
      </div>
      
      <div className="grid grid-cols-1 gap-4">
        {Object.entries(stats).map(([category, data]) => (
          <div 
            key={category}
            className={`p-4 rounded-lg ${
              category === 'pronunciation' ? 'bg-blue-50' :
              category === 'vocabulary' ? 'bg-green-50' :
              'bg-purple-50'
            }`}
          >
            <h3 className="font-semibold capitalize mb-2">{category}</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-gray-600">Average Score</p>
                <p className="font-semibold text-lg">
                  {data.averageScore.toFixed(1)}%
                </p>
              </div>
              <div>
                <p className="text-gray-600">Best Score</p>
                <p className="font-semibold text-lg">
                  {data.bestScore}%
                </p>
              </div>
              <div>
                <p className="text-gray-600">Completed</p>
                <p className="font-semibold text-lg">
                  {data.completed} exercises
                </p>
              </div>
              <div>
                <p className="text-gray-600">Improvement</p>
                <p className={`font-semibold text-lg ${
                  data.improvement > 0 ? 'text-green-600' : 
                  data.improvement < 0 ? 'text-red-600' : 
                  'text-gray-600'
                }`}>
                  {data.improvement ? `${data.improvement.toFixed(1)}%` : 'N/A'}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="h-64 mt-6">
        <Line data={chartData} options={options} />
      </div>

      <div className="mt-4 p-4 bg-gray-50 rounded-lg">
        <h3 className="font-semibold mb-2">Tips for Improvement</h3>
        <ul className="text-sm text-gray-600 space-y-1">
          <li>• Practice regularly to maintain progress</li>
          <li>• Focus on areas with lower scores</li>
          <li>• Review completed exercises periodically</li>
          <li>• Try to beat your personal best scores</li>
        </ul>
      </div>
    </div>
  );
};