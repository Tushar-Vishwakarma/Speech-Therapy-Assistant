import React, { useState } from 'react';
import { Exercise } from '../types';
import { Mic, Square, Play, ArrowLeft, Volume2 } from 'lucide-react';

interface ExerciseViewProps {
  exercise: Exercise;
  onComplete: (score: number) => void;
  onBack: () => void;
}

export const ExerciseView: React.FC<ExerciseViewProps> = ({ exercise, onComplete, onBack }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [attempts, setAttempts] = useState<number[]>([]);
  const [feedback, setFeedback] = useState('');
  const [currentWord, setCurrentWord] = useState(0);

  const simulateScoring = () => {
    // Simulate different scores based on attempts and randomness
    const baseScore = Math.floor(Math.random() * 30) + 70; // Base score between 70-100
    const attemptPenalty = attempts.length * 5; // Penalty for multiple attempts
    return Math.max(0, Math.min(100, baseScore - attemptPenalty));
  };

  const handleRecord = () => {
    setIsRecording(!isRecording);
    if (!isRecording) {
      // Simulating speech recognition with varying feedback
      setTimeout(() => {
        setIsRecording(false);
        const score = simulateScoring();
        const newAttempts = [...attempts, score];
        setAttempts(newAttempts);

        let feedbackMessage = '';
        if (score >= 90) {
          feedbackMessage = 'Excellent pronunciation! Keep up the great work! 🌟';
        } else if (score >= 75) {
          feedbackMessage = 'Good job! Try to speak a bit more clearly next time.';
        } else {
          feedbackMessage = 'Keep practicing! Focus on speaking slowly and clearly.';
        }

        setFeedback(feedbackMessage);

        // Move to next word if available
        if (currentWord < (exercise.content.targetWords?.length || 0) - 1) {
          setCurrentWord(prev => prev + 1);
        } else {
          // Calculate final score as average of all attempts
          const finalScore = Math.round(
            newAttempts.reduce((a, b) => a + b, 0) / newAttempts.length
          );
          onComplete(finalScore);
        }
      }, 2000);
    }
  };

  const getCurrentWord = () => {
    return exercise.content.targetWords?.[currentWord] || '';
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-lg">
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-4"
      >
        <ArrowLeft className="w-4 h-4" /> Back to exercises
      </button>

      <div className="flex flex-col md:flex-row gap-6">
        <div className="flex-1">
          <h2 className="text-2xl font-bold mb-4">{exercise.title}</h2>
          <p className="text-gray-600 mb-6">{exercise.description}</p>

          <div className="bg-blue-50 p-4 rounded-lg mb-6">
            <h3 className="font-semibold mb-2">Instructions:</h3>
            <p className="text-gray-700">{exercise.content.instructions}</p>
          </div>

          <div className="bg-green-50 p-4 rounded-lg mb-6">
            <h3 className="font-semibold mb-2">Examples:</h3>
            <ul className="list-disc list-inside">
              {exercise.content.examples.map((example, index) => (
                <li key={index} className="text-gray-700">{example}</li>
              ))}
            </ul>
          </div>

          {exercise.content.targetWords && (
            <div className="mb-6">
              <h3 className="font-semibold mb-2">Current Word:</h3>
              <div className="flex items-center gap-4 p-4 bg-purple-50 rounded-lg">
                <span className="text-2xl font-bold text-purple-800">
                  {getCurrentWord()}
                </span>
                <button
                  className="p-2 rounded-full bg-purple-100 hover:bg-purple-200 transition-colors"
                  onClick={() => {/* Add text-to-speech here */}}
                >
                  <Volume2 className="w-5 h-5 text-purple-800" />
                </button>
              </div>
              <div className="mt-2 flex gap-2">
                {exercise.content.targetWords.map((_, index) => (
                  <div
                    key={index}
                    className={`w-3 h-3 rounded-full ${
                      index === currentWord
                        ? 'bg-purple-500'
                        : index < currentWord
                        ? 'bg-green-500'
                        : 'bg-gray-300'
                    }`}
                  />
                ))}
              </div>
            </div>
          )}

          <div className="flex flex-col items-center gap-4">
            <button
              onClick={handleRecord}
              className={`p-4 rounded-full ${
                isRecording ? 'bg-red-500' : 'bg-blue-500'
              } text-white transition-colors hover:opacity-90`}
              disabled={isRecording}
            >
              {isRecording ? (
                <Square className="w-6 h-6" />
              ) : (
                <Mic className="w-6 h-6" />
              )}
            </button>
            <p className="text-sm text-gray-500">
              {isRecording ? 'Recording...' : 'Click to start recording'}
            </p>
          </div>

          {feedback && (
            <div className="mt-6 p-4 bg-green-50 rounded-lg">
              <p className="text-green-700">{feedback}</p>
              {attempts.length > 0 && (
                <div className="mt-2">
                  <p className="text-sm text-gray-600">
                    Latest attempt score: {attempts[attempts.length - 1]}%
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {exercise.content.imageUrl && (
          <div className="md:w-1/3">
            <img
              src={exercise.content.imageUrl}
              alt="Exercise visual aid"
              className="w-full rounded-lg shadow-md"
            />
          </div>
        )}
      </div>
    </div>
  );
};