import React from 'react';
import { Exercise } from '../types';
import { BookOpen, Mic, PenTool } from 'lucide-react';

interface ExerciseCardProps {
  exercise: Exercise;
  onSelect: (exercise: Exercise) => void;
}

export const ExerciseCard: React.FC<ExerciseCardProps> = ({ exercise, onSelect }) => {
  const getIcon = () => {
    switch (exercise.type) {
      case 'pronunciation':
        return <Mic className="w-6 h-6 text-blue-500" />;
      case 'vocabulary':
        return <BookOpen className="w-6 h-6 text-green-500" />;
      case 'sentence':
        return <PenTool className="w-6 h-6 text-purple-500" />;
    }
  };

  return (
    <div
      className={`p-4 rounded-lg shadow-md transition-all cursor-pointer
        ${exercise.completed ? 'bg-gray-50' : 'bg-white hover:shadow-lg'}`}
      onClick={() => onSelect(exercise)}
    >
      <div className="flex items-center gap-3 mb-2">
        {getIcon()}
        <h3 className="text-lg font-semibold">{exercise.title}</h3>
      </div>
      <p className="text-gray-600 mb-2">{exercise.description}</p>
      <div className="flex justify-between items-center">
        <span className="text-sm font-medium text-gray-500 capitalize">
          {exercise.difficulty}
        </span>
        {exercise.completed && (
          <span className="text-sm font-medium text-green-500">Completed</span>
        )}
      </div>
    </div>
  );
};