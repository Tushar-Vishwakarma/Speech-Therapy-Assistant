import React from 'react';
import { curriculumPlan } from '../data/curriculum';

export const CurriculumView: React.FC = () => {
  return (
    <div className="space-y-8">
      {Object.entries(curriculumPlan).map(([category, plan]) => (
        <div key={category} className="bg-white p-6 rounded-lg shadow-lg">
          <h2 className="text-2xl font-bold mb-2">{plan.title}</h2>
          <p className="text-gray-600 mb-4">{plan.description}</p>
          
          <div className="space-y-6">
            {plan.weeks.map((week) => (
              <div key={week.week} className="border-l-4 border-blue-500 pl-4">
                <h3 className="text-lg font-semibold mb-2">
                  Week {week.week}: {week.theme}
                </h3>
                <ul className="list-disc list-inside text-gray-600">
                  {week.goals.map((goal, index) => (
                    <li key={index}>{goal}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};